<!-- website header -->
<div id="header">
   <div class="row container">

      <div class="col4">
         <a href="<?php echo $website['url'];?>">
            <img src="<?php echo $website['url'];?>assets/img/logo.png?v=<?php echo $website['version'];?>" alt="<?php echo $website['name'];?>" />
         </a>
      </div>

   </div>
</div>